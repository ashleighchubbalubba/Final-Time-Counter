{\rtf1\ansi\ansicpg1252\cocoartf1671
{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww12600\viewh7280\viewkind0
\deftab560
\pard\pardeftab560\slleading20\partightenfactor0

\f0\fs24 \cf0 This is the Time Counter!\
\pard\pardeftab560\slleading20\pardirnatural\partightenfactor0
\cf0 \
\pard\pardeftab560\slleading20\partightenfactor0
\cf0 In order to start the program, open the files in an IntelliJ project. The time object from the time class has the ability to increment and decrement a certain amount of hours, minutes, and seconds in both standard and military time. A full day in standard time would start at 12 AM, then go to 12 PM, and then go back to 12AM, while a full day in military time would start at 24 AM, then go to 12 PM, and then go back to 24 AM.\
\
 The syntax for incrementation/decrementation is as follows:\
	time.changeHour(amount);\
	time.changeMinutes(amount);\
	time.changeSeconds(amount);\
Amount is the amount of the incrementation or decrementation (can be a positive or a negative number).\
\
I have created a JUnit test as the unit test stub. Run it by opening the file in the same project as the time class, then make sure IntelliJ has recognized that it is a JUnit file, and then press run to test all seven tests!}